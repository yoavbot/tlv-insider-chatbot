// Setup for when running with Karma
window._ = require( "lodash" );
window.machina = require( "machina" );
window.sinon = require( "sinon" );
