// Setup for running Mocha via Node
global._ = require( "lodash" );
global.sinon = require( "sinon" );
global.machina = require( "../../lib/machina" );
