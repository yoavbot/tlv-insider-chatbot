module.exports = {
	NEXT_TRANSITION: "transition",
	HANDLING: "handling",
	HANDLED: "handled",
	NO_HANDLER: "nohandler",
	TRANSITION: "transition",
	TRANSITIONED: "transitioned",
	INVALID_STATE: "invalidstate",
	DEFERRED: "deferred",
	NEW_FSM: "newfsm"
};
