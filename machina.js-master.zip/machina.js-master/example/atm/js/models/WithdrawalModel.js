var WithdrawalModel = Backbone.Model.extend( {
	defaults : {
		amount : 0,
		error  : ""
	}
} );