var DepositModel = Backbone.Model.extend( {
	defaults : {
		amount : 0,
		error  : ""
	}
} );